Modernizr.load({
  test: Modernizr.generatedcontent,
  nope: 'http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js'
});