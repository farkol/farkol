<?php if ( is_active_sidebar( 'header-widget-area' ) ) : ?>
		<div id="header-widget-area" class="widget-area" role="complementary">
			<?php dynamic_sidebar( 'header-widget-area' ); ?>
		</div><!-- #header-widget-area -->
<?php endif; ?>