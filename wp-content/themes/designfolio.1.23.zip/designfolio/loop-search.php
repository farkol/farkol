<?php
/**
 * The single post loop.
 *
 */
?>

<?php

	/* Use the framework blog page post loop. */
	PC_Template_Parts::search_page_loop( $s );

?>